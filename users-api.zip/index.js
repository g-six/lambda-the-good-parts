"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userApi = async (event = {}) => {
    const response = JSON.stringify(event, null, 2);
    return response;
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFDYSxRQUFBLE9BQU8sR0FBRyxLQUFLLEVBQUUsUUFBc0IsRUFBRSxFQUFnQixFQUFFO0lBQ3BFLE1BQU0sUUFBUSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQTtJQUN2RCxPQUFPLFFBQVEsQ0FBQTtBQUNuQixDQUFDLENBQUEifQ==